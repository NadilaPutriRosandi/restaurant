<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./dist/output.css">
</head>

<body class="w-full h-full flex flex-col">
    <nav class="flex justify-end items-end py-4 px-8 bg-amber-800">
        <a href="./auth/login.php" class="text-xl text-white font-bold font-sans hover:text-gray-500 duration-300">Login</a>
    </nav>
    <div class="flex flex-col w-full h-full bg-amber-200 justify-center items-center">
        <div class="w-full justify-center items-center flex py-8 flex-row px-8">
            <div class="w-1/2 flex flex-col">
                <span class="py-10 bg-amber-400 rounded text-white text-xl font-bold w-full text-center">
                    <span class="text-4xl underline">
                        NPR RESTO
                    </span>
                    <br>Teruntuk pelanggan brownies npr yang kami hormati. Terima banyak atas pembelian yang telah kamu lakukan. Sungguh pesanan Anda, sangat berarti banyak bagi perkembangan restoran kami. Selamat menikmati.</span>
                <a href="./user/index.php" class="py-2 px-4 mt-4 bg-amber-600 font-bold text-center text-xl text-white rounded">Pesan Sekarang</a>
            </div>
            <div class="w-1/2 flex flex-col">
                <img src="img/chef.png">
            </div>
        </div>
        <div class="w-full h-full flex flex-row bg-amber-400">
            <div class="w-1/2 p-8">
                <img src="./img/cake2.jpg" class="rounded">
            </div>
            <div class="w-1/2 p-8 flex justify-center items-center">
                <span class="p-4 bg-white text-xl font-semibold text-amber-600 rounded">
                Brownies yang fluffy dan padat, dengan lelehan coklat yang lumer di mulut, disajikan hangat bersama secangkir capuccino tentu menjadi ide menarik yang akan disukai oleh anggota keluarga maupun kerabat.</span>
            </div>
        </div>
        <div class="w-full h-full flex flex-row">
            <div class="w-1/2 p-8 flex justify-center items-center">
                <span class="p-4 bg-white text-xl font-semibold text-amber-600 rounded text-center">
                " ngumpul bareng keluarga dan kerabat memang paling cocok ditemani brownies lumer yang lembut, rasa nya yang lezat dapat membuat suasana menjadi happy."</span>
            </div>
            <div class="w-1/2 p-8">
                <img src="./img/cake1.jpg" class="rounded">
            </div>
        </div>
        <div class="w-full h-full flex flex-row bg-amber-400">
            <div class="w-1/2 p-8">
                <img src="./img/cake3.jpg" class="rounded">
            </div>
            <div class="w-1/2 p-8 flex justify-center items-center">
                <span class="p-4 bg-white text-xl font-semibold text-amber-600 rounded text-center">
                Di Kawasan Pontianak tepatnya di brownies npr kamu akan mendapatkan pengalaman tersebut dengan harga makanan di restoran yang cukup terjangkau.</span>
            </div>
        </div>
    </div>
</body>

</html>