<html>
<head>
    <title>Membuat Form Login</title>
</head>
<body>
    <form action="">
        <form>
            <div>
                <label>Username</label> <br>
                <input name="nama" type="text">
            </div>
            <div>
                <label>password</label> <br>
                <input name="passwordAkun" type="password">
            </div>
            <div>
                <button type="submit">submit</button>
            </div>
        </form>
    </form>
    <?php
    if (isset($_GET['nama']) | isset($_GET['passwordAkun'])) {
        echo "Nama : " . $_GET['nama'] . "<br> ";
        echo "Password : " . $_GET['passwordAkun'];
    }
    ?>
</body>
</html>