<?php

include("../config.php");
session_start();
if ($_SESSION["admin"] == "") {
    header('location: ../user/index.php');
}
$id = $_GET["id_biase"];
$data = mysqli_query($connection, "SELECT * FROM tb_user WHERE id_user = $id");
$row = mysqli_fetch_assoc($data);

function updateUser($data)
{
    global $connection;
    $id = $data["id"];
    $username = $data["username"];
    $level = $data["level"];
    $password = $data["password"];

    if ($level === "") {
        echo "
        <script>
            alert('harap isi status user')
            document.location.href == 'update-user.php'
        </script>
        ";
        return false;
    }

    mysqli_query($connection, "UPDATE tb_user SET
        username = '$username',
        level = '$level',
        password = '$password'
        WHERE id_user = $id
    ");

    return mysqli_affected_rows($connection);
}

if (isset($_POST["submit"])) {
    if (updateUser($_POST) > 0) {
        echo "
        <script>
            document.location.href = 'index.php'
        </script>
        ";
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../dist/output.css">
</head>

<body class="w-full flex flex-col justify-center items-center select-none h-screen">
    <nav class="w-full h-14 bg-amber-600 flex justify-between items-center px-10">
        <div class="text-white font-bold text-lg">
            <a href="#" class="hover:underline hover:underline-offset-4 mr-3">Home</a>
            <a href="../menu/index.php" class="hover:underline hover:underline-offset-4">Menu</a>
        </div>
        <div class="text-white font-bold text-lg">
            <a href="../auth/logout.php" class="hover:underline hover:underline-offset-4">Logout</a>
        </div>
    </nav>
    <div class="flex justify-center items-center w-full h-full">
        <form method="post" action="" class="w-1/2 h-3/5 border-2 border-amber-900 rounded-lg flex flex-col justify-center items-center mt-5 bg-amber-500 shadow-2xl">
            <input type="hidden" name="id" value="<?= $row["id_user"] ?>">
            <div class="w-full flex justify-center items-center my-2">
                <input type="text" name="username" value="<?= $row["username"] ?>" placeholder="Name" class="w-1/2 py-2 px-4 font-semibold text-lg focus:outline-none rounded-lg">
            </div>
            <div class="w-full flex justify-center items-center my-2">
                <input type="text" name="password" value="<?= $row["password"] ?>" placeholder="Password" class="w-1/2 py-2 px-4 font-semibold text-lg focus:outline-none rounded-lg">
            </div>
            <div class="w-1/2 flex justify-center items-center my-2">
                <select name="level" id="" class="w-full py-2 px-4 outline-none font-semibold text-lg rounded-lg" value-selected="<?= $row["level"] ?>" select>
                    <option value="">--</option>
                    <option value="admin">Admin</option>
                    <option value="kasir">Kasir</option>
                    <option value="user">User</option>
                </select>
            </div>
            <div class="w-1/2 flex justify-start items-center mb-2 mt-5">
                <a href="index.php" class="py-2 px-4 bg-red-500 border-2 border-white hover:bg-red-600 duration-300 mr-2 font-semibold text-lg rounded-lg text-white">Back</a>
                <button type="submit" name="submit" class="py-2 px-4 mr-2 bg-amber-600 border-2 border-white hover:bg-amber-700 duration-300 font-semibold text-lg rounded-lg text-white">Submit</button>
            </div>
        </form>
    </div>
</body>

</html>